import React , {Component} from 'react';
import {View,Text} from 'react-native';

export default class Store extends Component
{
    render() {
        return(
            <View>
                <Text>333</Text>
            </View>
        );
    }
}